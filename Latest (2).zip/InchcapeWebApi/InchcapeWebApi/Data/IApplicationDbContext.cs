﻿using InchcapeWebApi.Models;
using Microsoft.EntityFrameworkCore;

namespace InchcapeWebApi.Data
{
    public interface IApplicationDbContext : IDbContext
    {
        DbSet<VehicleDetail> VehicleDetails { get; set; }

        Task SaveChangesAsync();
    }
}
