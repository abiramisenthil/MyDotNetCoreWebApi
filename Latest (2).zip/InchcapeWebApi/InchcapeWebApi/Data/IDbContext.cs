﻿using Microsoft.EntityFrameworkCore;

namespace InchcapeWebApi.Data
{
    public interface IDbContext : IDisposable
    {
        DbContext Instance { get; }
    }
}
