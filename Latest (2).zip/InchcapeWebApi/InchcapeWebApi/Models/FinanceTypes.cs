﻿namespace InchcapeWebApi.Models
{
    public class FinanceTypes
    {
    }
}
